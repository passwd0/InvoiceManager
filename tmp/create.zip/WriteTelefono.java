Create table public.Telefono (
	"CodiceConto" varchar(25) NULL,
	"Progressivo" INTEGER NULL,
	"TipoTelefono" varchar(25) NULL,
	"Numero" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
