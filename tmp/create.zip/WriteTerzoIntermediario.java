Create table public.TerzoIntermediario (
	"IdentificaticoFiscale" varchar(25) NOT NULL,
	"Denominazione" varchar(25) NULL,
	"Nome" varchar(25) NULL,
	"Cognome" varchar(25) NULL,
	"CodEORI" varchar(25) NULL
);
