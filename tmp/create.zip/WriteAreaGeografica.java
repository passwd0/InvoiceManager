Create table public.AreaGeografica (
	"CodiceArea" INTEGER NULL,
	"Nazione" varchar(25) NULL,
	"Area" varchar(25) NULL,
	"Regione" varchar(25) NULL,
	"Provincia" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
