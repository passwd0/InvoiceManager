Create table public.UnitaMisura (
	"CodiceUnitaMisura" varchar(25) NULL,
	"Descrizione" varchar(25) NULL,
	"CodiceStato" Boolean NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
