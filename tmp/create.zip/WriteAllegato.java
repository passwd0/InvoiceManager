Create table public.Allegato (
	"NomeAllegato" varchar(25) NULL,
	"PathAllegato" varchar(25) NULL,
);
