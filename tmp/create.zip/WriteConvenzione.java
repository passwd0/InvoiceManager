Create table public.Convenzione (
	"NumeroConvenzione" INTEGER NULL,
	"NumeroRigaConvenzione" INTEGER NULL,
	"DataConvenzione" Date NULL,
	"CnvCodiceCommessaConvenzione" varchar(25) NULL,
	"CnvCodiceCUP" varchar(25) NULL,
	"CnvCodiceCIG" varchar(25) NULL,
);
