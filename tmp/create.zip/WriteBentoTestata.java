Create table public.BentoTestata (
	"CodiceBento" varchar(25) NULL,
	"Descrizione" varchar(25) NULL,
	"CodiceTipoBento" varchar(25) NULL,
	"CodiceMagazzino" varchar(25) NULL,
	"CodiceClienteFornitore" varchar(25) NULL,
	"Note" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
