Create table public.ArticoloMagazzinoDescrizioneMultilingua (
	"CodiceArticolo" varchar(25) NULL,
	"CodiceLingua" varchar(25) NULL,
	"Descrizione" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
