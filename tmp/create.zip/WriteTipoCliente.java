Create table public.TipoCliente (
	"CodiceTipoCliente" varchar(25) NULL,
	"Descrizione" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL
);
