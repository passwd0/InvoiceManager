Create table public.Ricezione (
	"NumeroRicezione" INTEGER NULL,
	"NumeroRigaRicezione" INTEGER NULL,
	"DataRicezione" Date NULL,
	"RczCodiceCommessaRicezione" varchar(25) NULL,
	"RczCodiceCUP" varchar(25) NULL,
	"RczCodiceCIG" varchar(25) NULL,
);
