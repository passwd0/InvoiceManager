Create table public.CodiceABarre (
	"CodiceArticolo" varchar(25) NULL,
	"CodiceABarre" varchar(25) NULL,
	"Tipo" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
