Create table public.AltroDatoGestionale (
	"TipoDato" varchar(25) NULL,
	"RiferimentoTesto" varchar(25) NULL,
	"RiferimentoNumero" Float NULL,
	"RiferimentoData" Date NULL,
);
