Create table public.Vettore (
	"CodiceVettore" varchar(25) NOT NULL,
	"Descrizione" varchar(25) NULL,
	"CodiceStato" varchar(25) NULL,
	"Via" varchar(25) NULL,
	"Citta" varchar(25) NULL,
	"PartitaIva" varchar(25) NULL,
	"Iscrizione" varchar(25) NULL,
	"Telefono" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL
);
