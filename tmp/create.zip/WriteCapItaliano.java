Create table public.CapItaliano (
	"Id" INTEGER NULL,
	"Cap" varchar(25) NULL,
	"Comune" varchar(25) NULL,
	"Provincia" varchar(25) NULL,
	"Nazione" varchar(25) NULL,
	"CodiceISTAT" varchar(25) NULL,
	"CodiceCAB" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
