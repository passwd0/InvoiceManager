Create table public.Ordine (
	"NumeroOrdine" INTEGER NULL,
	"NumeroRigaOrdine" INTEGER NULL,
	"DataOrdine" Date NULL,
	"OrdCodiceCommessaConvenzione" varchar(25) NULL,
	"OrdCodiceCUP" varchar(25) NULL,
	"OrdCodiceCIG" varchar(25) NULL,
);
