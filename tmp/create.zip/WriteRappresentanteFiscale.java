Create table public.RappresentanteFiscale (
	"Paese" varchar(25) NOT NULL,
	"IdentificativoFiscale" varchar(25) NULL,
	"Denominazione" varchar(25) NULL,
	"Nome" varchar(25) NULL,
	"Cognome" varchar(25) NULL
);
