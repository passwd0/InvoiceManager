Create table public.RaggruppamentoClienteFornitore (
	"CodiceRaggruppamento" varchar(25) NOT NULL,
	"Descrizione" varchar(25) NULL,
	"CodiceStato" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL
);
