Create table public.Controparte (
	"CodiceControparte" varchar(25) NOT NULL,
	"Descrizione" varchar(25) NULL,
	"Stato().name" varchar(25) NULL,
	"CodiceContoCOGE" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL
);
