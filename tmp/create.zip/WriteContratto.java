Create table public.Contratto (
	"NumeroContratto" INTEGER NULL,
	"NumeroRigaContratto" INTEGER NULL,
	"DataContratto" Date NULL,
	"CntCodiceCommessaConvenzione" varchar(25) NULL,
	"CntCodiceCUP" varchar(25) NULL,
	"CntCodiceCIG" varchar(25) NULL,
);
