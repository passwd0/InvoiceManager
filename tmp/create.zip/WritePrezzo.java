Create table public.Prezzo (
	"Id" INTEGER NULL,
	"CodiceListinoPersonalizzato" INTEGER NULL,
	"Prezzo" Float NULL,
);
