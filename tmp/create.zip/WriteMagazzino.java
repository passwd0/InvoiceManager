Create table public.Magazzino (
	"CodiceMagazzino" varchar(25) NULL,
	"Descrizione" varchar(25) NULL,
	"CodiceStato" Boolean NULL,
	"CodiceTipoMagazzino" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
