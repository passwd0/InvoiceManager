Create table public.ResaMerce (
	"CodiceResa" varchar(25) NULL,
	"Descrizione" varchar(25) NULL,
	"CodiceStato" varchar(25) NULL,
	"PercentualeAddebito" Float NULL,
	"ImportoMinimo" Float NULL,
	"IndicatoreProvvigione" Boolean NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL
);
