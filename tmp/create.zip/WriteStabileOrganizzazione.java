Create table public.StabileOrganizzazione (
	"SoIndirizzo" varchar(25) NOT NULL,
	"SoNumeroCivico" varchar(25) NULL,
	"SoCap" varchar(25) NULL,
	"SoComune" varchar(25) NULL,
	"SoProvincia" varchar(25) NULL,
	"SoNazione" varchar(25) NULL
);
