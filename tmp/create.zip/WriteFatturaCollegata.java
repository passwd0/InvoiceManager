Create table public.FatturaCollegata (
	"NumeroFtCollegate" INTEGER NULL,
	"NumeroRigaFtCollegate" INTEGER NULL,
	"DataFtCollegate" Date NULL,
	"FtcCodiceCommessaFtCollegate" varchar(25) NULL,
	"FtcCodiceCUP" varchar(25) NULL,
	"FtcCodiceCIG" varchar(25) NULL,
);
