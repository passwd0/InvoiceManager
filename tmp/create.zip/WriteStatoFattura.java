Create table public.StatoFattura (
	"IndicatoreStatoAvanzamento" Boolean NULL,
	"TipoDocumento" Boolean NULL,
	"Descrizione" varchar(25) NULL,
	"DataInserimento" Timestamp NULL,
	"DataUltimaModifica" Timestamp NULL,
);
